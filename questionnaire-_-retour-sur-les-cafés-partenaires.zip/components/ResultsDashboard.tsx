
import React, { useMemo, useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { Submission, ChartData } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from './ui/Card';
import { SparklesIcon } from './icons';
import { GoogleGenAI } from '@google/genai';


interface ResultsDashboardProps {
  submissions: Submission[];
}

const PIE_COLORS = ['#0077b6', '#00b4d8'];
const BAR_COLOR = '#00b4d8';
const RADAR_STROKE_COLOR = '#0077b6';
const RADAR_FILL_COLOR = '#00b4d8';


const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const value = payload[0].value;
    const name = payload[0].name || payload[0].payload?.subject;
    const payloadName = payload[0].payload?.name || name;
    return (
      <div className="bg-white/80 backdrop-blur-sm p-2 border border-gray-300 rounded-lg shadow-lg max-w-xs">
        <p className="font-bold text-brand-text break-words">{payloadName}</p>
        <p className="text-sm text-brand-secondary">{`Réponses: ${typeof value === 'number' ? value.toFixed(0) : value}`}</p>
      </div>
    );
  }
  return null;
};

const BarChartCard = ({ title, data, yAxisWidth = 100 }: { title: string, data: ChartData, yAxisWidth?: number }) => (
    <Card>
      <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
            <XAxis type="number" allowDecimals={false} stroke="#888888" />
            <YAxis type="category" dataKey="name" width={yAxisWidth} stroke="#888888" interval={0} />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(173, 232, 244, 0.2)' }} />
            <Bar dataKey="value" name="Nombre de réponses" fill={BAR_COLOR} barSize={20} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
);

const PieChartCard = ({ title, data }: { title: string, data: ChartData }) => (
   <Card>
    <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
    <CardContent>
       <ResponsiveContainer width="100%" height={300}>
          <PieChart>
              <Pie data={data} cx="50%" cy="50%" labelLine={false} label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`} outerRadius={100} fill="#8884d8" dataKey="value">
                  {data.map((entry, index) => <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />)}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend />
          </PieChart>
      </ResponsiveContainer>
    </CardContent>
  </Card>
);

const RadarChartCard = ({ title, data }: { title: string, data: { subject: string; A: number; fullMark: number }[] }) => (
  <Card>
      <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
      <CardContent>
          <ResponsiveContainer width="100%" height={300}>
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
                  <PolarGrid stroke="rgba(128, 128, 128, 0.3)" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: 'currentColor', fontSize: 12 }} />
                  <PolarRadiusAxis angle={30} domain={[1, 7]} tickCount={7} tick={{ fill: 'transparent' }} axisLine={false} />
                  <Radar name="Impact moyen" dataKey="A" stroke={RADAR_STROKE_COLOR} fill={RADAR_FILL_COLOR} fillOpacity={0.6} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend formatter={(value, entry) => <span className="text-brand-text">{value}</span>} />
              </RadarChart>
          </ResponsiveContainer>
      </CardContent>
  </Card>
);

const TextResponsesCard = ({ title, responses }: { title: string, responses: string[] }) => {
    if (responses.length === 0) return null;
    return (
        <Card>
            <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
            <CardContent>
                <ul className="space-y-3 max-h-60 overflow-y-auto pr-2">
                    {responses.map((res, i) => (
                    <li key={i} className="bg-gray-100 p-3 rounded-md italic text-brand-text-light">"{res}"</li>
                    ))}
                </ul>
            </CardContent>
        </Card>
    );
};

const ResultsDashboard: React.FC<ResultsDashboardProps> = ({ submissions }) => {
  const [summary, setSummary] = useState('');
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);
  const [summaryError, setSummaryError] = useState('');

  const totalSubmissions = submissions.length;

  const data = useMemo(() => {
    if (totalSubmissions === 0) return null;

    const cafeParticipants = submissions.filter(s => s.participatedInCafes === 'Oui');
    
    const formatChartData = (data: Record<string, number>): ChartData =>
      Object.entries(data).map(([name, value]) => ({ name, value })).sort((a,b) => b.value - a.value);

    // --- DATA PROCESSING ---

    const participatedCafes = submissions.reduce((acc, s) => {
        acc[s.participatedInCafes] = (acc[s.participatedInCafes] || 0) + 1;
        return acc;
    }, {} as Record<'Oui' | 'Non', number>);

    const cafesKnowledge = cafeParticipants.reduce((acc, s) => {
        s.cafesKnowledge?.forEach(k => {
            const label = k === 'equipes' ? 'Équipe CAP' : 'Autres partenaires';
            acc[label] = (acc[label] || 0) + 1;
        });
        return acc;
    }, {} as Record<string, number>);

    const cafesCommunication = cafeParticipants.reduce((acc, s) => {
        if (s.cafesCommunication) acc[s.cafesCommunication] = (acc[s.cafesCommunication] || 0) + 1;
        return acc;
    }, {} as Record<'Oui' | 'Non', number>);

    const cafesEnjoyment = cafeParticipants.reduce((acc, s) => {
        s.cafesEnjoyment?.forEach(e => {
            const label = {
                decouverte: 'Découverte structures', discussion: 'Discussion libre',
                informels: 'Moments informels', autre: 'Autre'
            }[e] || e;
            acc[label] = (acc[label] || 0) + 1;
        });
        return acc;
    }, {} as Record<string, number>);

    const observedChallenges = submissions.reduce((acc, s) => {
        s.observedChallenges.forEach(c => {
             const label = {
                sante_mentale: 'Santé mentale', precarite: 'Précarité', decrochage: 'Décrochage',
                migration: 'Migration', addictions: 'Addictions', conflits: 'Conflits', autre: 'Autre'
            }[c] || c;
            acc[label] = (acc[label] || 0) + 1;
        });
        return acc;
    }, {} as Record<string, number>);
    
    const challengesRanking = submissions.reduce<Record<string, { total: number, count: number }>>((acc, s) => {
        Object.entries(s.challengesRanking).forEach(([key, value]) => {
            const label = {
                sante_mentale: 'Santé mentale', precarite: 'Précarité', decrochage: 'Décrochage',
                migration: 'Migration', addictions: 'Addictions', conflits: 'Conflits'
            }[key] || key;
            if (!acc[label]) acc[label] = { total: 0, count: 0 };
            acc[label].total += value;
            acc[label].count += 1;
        });
        return acc;
    }, {});
    
    const challengesRankingAvg = Object.entries(challengesRanking).map(([name, {total, count}]) => ({
        subject: name, A: total/count, fullMark: 7
    }));

    const professionalRoles = submissions.reduce((acc, s) => {
        const role = s.professionalRole === 'Autre' ? s.professionalRoleOther || 'Autre (non précisé)' : s.professionalRole;
        if (role) acc[role] = (acc[role] || 0) + 1;
        return acc;
    }, {} as Record<string, number>);

    const textResponses = {
        cafesCommReason: cafeParticipants.map(s => s.cafesCommunicationReason).filter(Boolean) as string[],
        cafesEnjoymentOther: cafeParticipants.map(s => s.cafesEnjoymentOther).filter(Boolean) as string[],
        observedChallengesOther: submissions.map(s => s.observedChallengesOther).filter(Boolean) as string[],
        specializationObstacles: submissions.map(s => s.specializationObstacles).filter(Boolean) as string[],
    };

    return {
      participatedCafes: formatChartData(participatedCafes),
      cafesKnowledge: formatChartData(cafesKnowledge),
      cafesCommunication: formatChartData(cafesCommunication),
      cafesEnjoyment: formatChartData(cafesEnjoyment),
      observedChallenges: formatChartData(observedChallenges),
      challengesRankingAvg,
      professionalRoles: formatChartData(professionalRoles),
      textResponses
    };
  }, [submissions, totalSubmissions]);
  
   useEffect(() => {
    const generateSummary = async () => {
      if (!data) return;

      try {
        setIsLoadingSummary(true);
        setSummaryError('');
        
        if (!process.env.API_KEY) {
            throw new Error("La clé API n'est pas configurée.");
        }
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const prompt = `
          Tu es un analyste de données expert pour une organisation sociale à Genève.
          Analyse les données agrégées suivantes, issues d'un questionnaire destiné à des professionnels du terrain travaillant avec des jeunes en rupture.

          Rédige une synthèse exécutive concise et percutante en français. Utilise des listes à puces pour 3 à 4 points clés. L'objectif est de fournir un aperçu rapide et actionnable pour des directeurs ou décideurs politiques.

          Concentre-toi sur les tendances les plus significatives, les surprises, ou les points de friction. Ne te contente pas de lister les chiffres, interprète-les brièvement.

          Données à analyser :
          ${JSON.stringify({
            totalSubmissions: submissions.length,
            participation_cafes: data.participatedCafes,
            roles_professionnels: data.professionalRoles,
            appreciation_cafes: data.cafesEnjoyment,
            defis_observes: data.observedChallenges,
            impact_moyen_defis: data.challengesRankingAvg,
            nombre_d_obstacles_remontes: data.textResponses.specializationObstacles.length,
          }, null, 2)}
        `;
        
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });

        setSummary(response.text);
      } catch (err) {
        console.error("Error generating AI summary:", err);
        setSummaryError("Une erreur est survenue lors de la génération de la synthèse.");
      } finally {
        setIsLoadingSummary(false);
      }
    };

    if (submissions.length >= 3 && !summary && !isLoadingSummary && !summaryError) {
      generateSummary();
    } else if (submissions.length > 0 && submissions.length < 3 && !summaryError) {
      setSummaryError("Pas assez de réponses (3 minimum) pour générer une synthèse pertinente.");
    }
  }, [data, submissions.length, summary, isLoadingSummary, summaryError]);


  if (totalSubmissions === 0) {
    return (
      <Card>
        <CardHeader><CardTitle>Résultats du Questionnaire</CardTitle></CardHeader>
        <CardContent><p className="text-center text-brand-text-light py-10">Aucune réponse n'a été soumise pour le moment.</p></CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <SparklesIcon className="h-6 w-6 text-brand-secondary mr-2" />
            Synthèse par IA
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingSummary && <p className="text-center text-brand-text-light py-4">Génération de la synthèse en cours...</p>}
          {summaryError && <p className="text-center text-brand-danger py-4">{summaryError}</p>}
          {summary && <div className="text-brand-text space-y-2" style={{ whiteSpace: 'pre-wrap' }}>{summary}</div>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Synthèse des Réponses</CardTitle></CardHeader>
        <CardContent><p className="text-xl font-bold text-brand-primary">{totalSubmissions} <span className="font-normal text-base text-brand-text-light">réponse(s) au total</span></p></CardContent>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {data?.participatedCafes && <PieChartCard title="Participation aux cafés partenaires" data={data.participatedCafes} />}
        {data?.professionalRoles && data.professionalRoles.length > 0 && <BarChartCard title="Répartition par rôle professionnel" data={data.professionalRoles} yAxisWidth={200} />}
      </div>
      
      <hr className="my-8 border-gray-300"/>
      <h2 className="text-2xl font-bold text-center text-brand-text mb-6">Retours sur les Cafés Partenaires</h2>

      {data?.cafesKnowledge && data.cafesKnowledge.length > 0 && <BarChartCard title="Permet de mieux connaître..." data={data.cafesKnowledge} />}

      {data?.cafesCommunication && data.cafesCommunication.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PieChartCard title="Facilite la communication" data={data.cafesCommunication} />
            <TextResponsesCard title="Raisons si 'Non'" responses={data.textResponses.cafesCommReason} />
        </div>
      )}

      {data?.cafesEnjoyment && data.cafesEnjoyment.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <BarChartCard title="Aspects les plus appréciés des cafés" data={data.cafesEnjoyment} />
          <TextResponsesCard title="Autres aspects appréciés" responses={data.textResponses.cafesEnjoymentOther} />
        </div>
      )}
      
      <hr className="my-8 border-gray-300"/>
      <h2 className="text-2xl font-bold text-center text-brand-text mb-6">Perception des Problématiques des Jeunes</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {data?.observedChallenges && <BarChartCard title="Défis les plus observés" data={data.observedChallenges} />}
        <TextResponsesCard title="Autres défis observés" responses={data.textResponses.observedChallengesOther} />
      </div>
      
      {data?.challengesRankingAvg && data.challengesRankingAvg.length > 0 && <RadarChartCard title="Impact moyen perçu des problématiques" data={data.challengesRankingAvg} />}
      
      <TextResponsesCard title="Obstacles dans l'accompagnement professionnel" responses={data.textResponses.specializationObstacles} />

    </div>
  );
};

export default ResultsDashboard;