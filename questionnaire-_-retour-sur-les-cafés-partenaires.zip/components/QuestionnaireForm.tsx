
import React, { useState, useMemo } from 'react';
import { Submission } from '../types';
import { ArrowRightIcon } from './icons';

interface QuestionnaireFormProps {
  onSubmit: (submission: Submission) => void;
}

const professionalRoles = [
  "Animateur·trice socioculturel·le",
  "Assistant·e social·e",
  "Chargé·e d'accompagnement / d'insertion professionnelle",
  "Coach en insertion",
  "Conseiller·ère en formation",
  "Conseiller·ère en orientation",
  "Coordinateur·trice de projet",
  "Curateur·trice / Tuteur·trice professionnel·le",
  "Directeur·trice / Responsable de service",
  "Éducateur·trice social·e",
  "Formateur·trice (en entreprise, atelier, etc.)",
  "Intervenant·e socio-éducatif·ve",
  "Logopédiste / Spécialiste en troubles d'apprentissage",
  "Maître·sse socioprofessionnel·le",
  "Mentor·e en entreprise",
  "Psychologue",
  "Psychopédagogue",
  "Travailleur·euse social·e (HES)",
  "Travailleur·euse social·e hors murs (TSHM)",
  "Autre"
];


const QuestionnaireForm: React.FC<QuestionnaireFormProps> = ({ onSubmit }) => {
  const [email, setEmail] = useState('');
  const [participated, setParticipated] = useState<'Oui' | 'Non' | null>(null);

  // Section 2 state
  const [cafesKnowledge, setCafesKnowledge] = useState<('equipes' | 'partenaires')[]>([]);
  const [cafesComm, setCafesComm] = useState<'Oui' | 'Non' | null>(null);
  const [cafesCommReason, setCafesCommReason] = useState('');
  const [cafesEnjoyment, setCafesEnjoyment] = useState<string[]>([]);
  const [cafesEnjoymentOther, setCafesEnjoymentOther] = useState('');
  
  // Section 3 state
  const [challenges, setChallenges] = useState<string[]>([]);
  const [challengesOther, setChallengesOther] = useState('');
  const [ranking, setRanking] = useState({
      sante_mentale: 4, precarite: 4, decrochage: 4,
      migration: 4, addictions: 4, conflits: 4,
  });
  const [obstacles, setObstacles] = useState('');
  const [professionalRole, setProfessionalRole] = useState('');
  const [professionalRoleOther, setProfessionalRoleOther] = useState('');

  const [currentSection, setCurrentSection] = useState(1);
  const [error, setError] = useState('');

  const totalSections = participated === 'Oui' ? 3 : 2;
  const progress = useMemo(() => {
    if (participated === null) return 0;
    const baseProgress = 100 / totalSections * (currentSection - 1);
    return Math.min(100, baseProgress);
  }, [currentSection, totalSections, participated]);

  const handleNextSection = (next: number) => {
    if (currentSection === 1 && !participated) {
      setError("Veuillez répondre à cette question pour continuer.");
      return;
    }
    setError('');
    setCurrentSection(next);
  };
  
  const handleCheckboxChange = (setter: React.Dispatch<React.SetStateAction<string[]>>, value: string) => {
      setter(prev => prev.includes(value) ? prev.filter(i => i !== value) : [...prev, value]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!obstacles) {
        setError("Veuillez remplir le champ sur les obstacles professionnels.");
        return;
    }
     if (!professionalRole) {
        setError("Veuillez sélectionner votre rôle professionnel.");
        return;
    }
    if (professionalRole === 'Autre' && !professionalRoleOther.trim()) {
        setError("Veuillez préciser votre rôle professionnel si vous sélectionnez 'Autre'.");
        return;
    }
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
        setError("Veuillez fournir une adresse e-mail valide.");
        return;
    }
    setError('');

    const submission: Submission = {
      id: new Date().toISOString() + Math.random(),
      email,
      submittedAt: new Date().toISOString(),
      participatedInCafes: participated!,
      observedChallenges: challenges as Submission['observedChallenges'],
      observedChallengesOther: challenges.includes('autre') ? challengesOther : undefined,
      challengesRanking: ranking as Submission['challengesRanking'],
      specializationObstacles: obstacles,
      professionalRole,
      professionalRoleOther: professionalRole === 'Autre' ? professionalRoleOther : undefined,
    };
    
    if (participated === 'Oui') {
        submission.cafesKnowledge = cafesKnowledge;
        submission.cafesCommunication = cafesComm!;
        submission.cafesCommunicationReason = cafesComm === 'Non' ? cafesCommReason : undefined;
        submission.cafesEnjoyment = cafesEnjoyment as Submission['cafesEnjoyment'];
        submission.cafesEnjoymentOther = cafesEnjoyment.includes('autre') ? cafesEnjoymentOther : undefined;
    }

    onSubmit(submission);
  };

  const renderSectionHeader = (title: string, description?: string) => (
    <div className="mb-6 pb-4 border-b border-gray-300">
      <h2 className="text-2xl font-bold text-brand-primary">{title}</h2>
      {description && <p className="mt-2 text-brand-text-light">{description}</p>}
    </div>
  );

  const renderQuestion = (title: string, children: React.ReactNode) => (
    <div className="mb-8">
      <p className="font-semibold text-lg mb-3 text-brand-text">{title}</p>
      {children}
    </div>
  );

  return (
    <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-10">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-extrabold text-brand-text tracking-tight">Retour sur les Cafés Partenaires</h1>
        <p className="mt-4 max-w-3xl mx-auto text-brand-text-light">
          Ce questionnaire vise d'abord à recueillir votre avis sur nos "Cafés Partenaires". Votre retour est essentiel pour améliorer ces moments d'échange. Dans un second temps, nous souhaitons bénéficier de votre expertise de terrain pour mieux comprendre les problématiques actuelles des jeunes en rupture.
        </p>
      </div>
      
      {error && <div className="bg-red-100 border border-red-400 text-brand-danger px-4 py-3 rounded-md relative mb-6" role="alert">{error}</div>}
      
      <div className="mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-brand-secondary h-2.5 rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
        </div>
        <p className="text-sm text-right mt-1 text-brand-text-light">Progression</p>
      </div>

      <form onSubmit={handleSubmit}>
        {currentSection === 1 && (
          <section>
            {renderSectionHeader("Participation")}
            {renderQuestion("Avez-vous déjà participé à un ou plusieurs cafés partenaires de CAP Formations ?", (
              <div className="flex space-x-4">
                {['Oui', 'Non'].map(option => (
                  <button type="button" key={option} onClick={() => setParticipated(option as 'Oui' | 'Non')} className={`w-full text-center px-6 py-3 rounded-lg text-lg font-bold transition-all duration-200 ${participated === option ? 'bg-brand-primary text-white scale-105 shadow-lg' : 'bg-gray-200 hover:bg-gray-300'}`}>
                    {option}
                  </button>
                ))}
              </div>
            ))}
            <div className="text-right mt-8">
                <button type="button" onClick={() => handleNextSection(participated === 'Oui' ? 2 : 3)} className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-secondary hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary disabled:opacity-50" disabled={!participated}>
                    Suivant <ArrowRightIcon className="ml-2" />
                </button>
            </div>
          </section>
        )}

        {currentSection === 2 && participated === 'Oui' && (
          <section>
            {renderSectionHeader("Retour sur les Cafés Partenaires")}
            {renderQuestion("Ces rencontres vous permettent-elles de mieux connaître...", (
              <div className="space-y-2">
                {[{id: 'equipes', label: "L'équipe de CAP Formations"}, {id: 'partenaires', label: 'Les autres partenaires présents'}].map(opt => (
                  <label key={opt.id} className="flex items-center p-3 rounded-lg bg-gray-50 hover:bg-gray-100 cursor-pointer">
                    <input type="checkbox" checked={cafesKnowledge.includes(opt.id as 'equipes' | 'partenaires')} onChange={() => handleCheckboxChange(setCafesKnowledge, opt.id)} className="h-5 w-5 rounded border-gray-300 text-brand-secondary focus:ring-brand-secondary" />
                    <span className="ml-3 text-brand-text">{opt.label}</span>
                  </label>
                ))}
              </div>
            ))}
             {renderQuestion("Ces rencontres facilitent-elles la communication et la collaboration ?", (
               <div className="flex space-x-4">
                  <button type="button" onClick={() => setCafesComm('Oui')} className={`w-full text-center px-6 py-3 rounded-lg font-bold transition-all ${cafesComm === 'Oui' ? 'bg-brand-secondary text-white' : 'bg-gray-200'}`}>Oui</button>
                  <button type="button" onClick={() => setCafesComm('Non')} className={`w-full text-center px-6 py-3 rounded-lg font-bold transition-all ${cafesComm === 'Non' ? 'bg-brand-danger text-white' : 'bg-gray-200'}`}>Non</button>
               </div>
            ))}
            {cafesComm === 'Non' && renderQuestion("Pourquoi ?", (
              <input type="text" value={cafesCommReason} onChange={e => setCafesCommReason(e.target.value)} placeholder="Votre explication..." className="w-full p-2 border rounded-md bg-gray-50 border-gray-300" />
            ))}
            {renderQuestion("Quels aspects des Cafés Partenaires appréciez-vous le plus ?", (
              <div className="space-y-2">
                  {[{id: 'decouverte', label: 'Découverte des structures des autres partenaires'}, {id: 'discussion', label: 'Discussion libre sur les collaborations'}, {id: 'informels', label: 'Moments informels favorisant les échanges humains'}, {id: 'autre', label: 'Autre'}].map(opt => (
                    <div key={opt.id}>
                      <label className="flex items-center p-3 rounded-lg bg-gray-50 hover:bg-gray-100 cursor-pointer">
                        <input type="checkbox" checked={cafesEnjoyment.includes(opt.id)} onChange={() => handleCheckboxChange(setCafesEnjoyment, opt.id)} className="h-5 w-5 rounded border-gray-300 text-brand-secondary focus:ring-brand-secondary" />
                        <span className="ml-3 text-brand-text">{opt.label}</span>
                      </label>
                      {opt.id === 'autre' && cafesEnjoyment.includes('autre') && (
                        <input type="text" value={cafesEnjoymentOther} onChange={e => setCafesEnjoymentOther(e.target.value)} placeholder="Précisez..." className="w-full mt-2 p-2 border rounded-md bg-gray-50 border-gray-300" />
                      )}
                    </div>
                  ))}
              </div>
            ))}
            <div className="text-right mt-8">
                <button type="button" onClick={() => handleNextSection(3)} className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-secondary hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary">
                    Suivant <ArrowRightIcon className="ml-2" />
                </button>
            </div>
          </section>
        )}

        {currentSection === 3 && (
          <section>
            {renderSectionHeader("Perception des problématiques des jeunes", "Votre expertise nous est précieuse pour affiner notre compréhension.")}
            {renderQuestion("Parmi ces défis, lesquels observez-vous le plus souvent ?", (
                <div className="space-y-2">
                    {[{id: 'sante_mentale', label: 'Santé mentale'}, {id: 'precarite', label: 'Précarité économique et sociale'}, {id: 'decrochage', label: 'Décrochage scolaire'}, {id: 'migration', label: 'Migration et intégration culturelle'}, {id: 'addictions', label: 'Addictions'}, {id: 'conflits', label: 'Conflits familiaux'}, {id: 'autre', label: 'Autre'}].map(opt => (
                        <div key={opt.id}>
                            <label className="flex items-center p-3 rounded-lg bg-gray-50 hover:bg-gray-100 cursor-pointer">
                                <input type="checkbox" checked={challenges.includes(opt.id)} onChange={() => handleCheckboxChange(setChallenges, opt.id)} className="h-5 w-5 rounded border-gray-300 text-brand-secondary focus:ring-brand-secondary" />
                                <span className="ml-3 text-brand-text">{opt.label}</span>
                            </label>
                            {opt.id === 'autre' && challenges.includes('autre') && (
                                <input type="text" value={challengesOther} onChange={e => setChallengesOther(e.target.value)} placeholder="Précisez..." className="w-full mt-2 p-2 border rounded-md bg-gray-50 border-gray-300" />
                            )}
                        </div>
                    ))}
                </div>
            ))}
            {renderQuestion("Classez ces problématiques selon leur impact perçu sur les jeunes (1: Faible, 7: Majeur)", (
                <div className="space-y-4">
                    {[{id: 'sante_mentale', label: 'Santé mentale'}, {id: 'precarite', label: 'Précarité économique et sociale'}, {id: 'decrochage', label: 'Décrochage scolaire'}, {id: 'migration', label: 'Migration et intégration culturelle'}, {id: 'addictions', label: 'Addictions'}, {id: 'conflits', label: 'Conflits familiaux'}].map(opt => (
                        <div key={opt.id} className="p-3 bg-gray-100 rounded-lg">
                            <label htmlFor={opt.id} className="block text-md font-medium text-brand-text mb-2">{opt.label}</label>
                            <div className="flex items-center space-x-2">
                                <span className="text-sm">1</span>
                                <input type="range" id={opt.id} min="1" max="7" value={ranking[opt.id as keyof typeof ranking]} onChange={e => setRanking(prev => ({...prev, [opt.id]: parseInt(e.target.value)}))} className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-brand-secondary" />
                                <span className="text-sm">7</span>
                                <span className="font-bold text-brand-primary w-4 text-center">{ranking[opt.id as keyof typeof ranking]}</span>
                            </div>
                        </div>
                    ))}
                </div>
            ))}
            {renderQuestion("Dans votre pratique professionnelle, quels sont les principaux obstacles ou difficultés que vous rencontrez pour accompagner efficacement les jeunes ?", (
              <textarea value={obstacles} onChange={e => setObstacles(e.target.value)} rows={5} placeholder="Ex: Manque de temps, complexité des cas, manque de collaboration entre services, etc." className="w-full p-2 border rounded-md bg-gray-50 border-gray-300"></textarea>
            ))}

            <div className="mt-10 pt-6 border-t border-gray-300">
                {renderQuestion("Quel est votre rôle professionnel ?", (
                    <>
                        <select
                            value={professionalRole}
                            onChange={e => setProfessionalRole(e.target.value)}
                            className="w-full p-3 border rounded-md bg-gray-50 border-gray-300 focus:ring-2 focus:ring-brand-accent focus:border-brand-accent"
                            required
                        >
                            <option value="" disabled>-- Sélectionnez votre rôle --</option>
                            {professionalRoles.map(role => (
                                <option key={role} value={role}>{role}</option>
                            ))}
                        </select>
                        {professionalRole === 'Autre' && (
                            <input
                                type="text"
                                value={professionalRoleOther}
                                onChange={e => setProfessionalRoleOther(e.target.value)}
                                placeholder="Veuillez préciser votre rôle"
                                className="w-full mt-2 p-3 border rounded-md bg-gray-50 border-gray-300 focus:ring-2 focus:ring-brand-accent focus:border-brand-accent"
                                required
                            />
                        )}
                    </>
                ))}
                {renderQuestion("Veuillez entrer votre adresse e-mail pour soumettre.", (
                    <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="votre.email@example.com" required className="w-full p-3 border rounded-md bg-gray-50 border-gray-300 focus:ring-2 focus:ring-brand-accent focus:border-brand-accent" />
                ))}
                <button type="submit" className="w-full mt-4 flex justify-center items-center px-6 py-4 border border-transparent text-lg font-medium rounded-md shadow-sm text-white bg-brand-success hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                    Soumettre le questionnaire
                </button>
                 <p className="text-center text-sm text-brand-text-light mt-4">
                  Nous vous remercions sincèrement pour le temps que vous avez consacré à partager votre expertise. Votre contribution est essentielle et nous aidera concrètement à renforcer nos collaborations et à affiner nos actions pour les jeunes à Genève.
                </p>
            </div>
          </section>
        )}
      </form>
    </div>
  );
};

export default QuestionnaireForm;
