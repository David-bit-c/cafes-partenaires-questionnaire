
import React from 'react';

export const FormIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
    <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
  </svg>
);

export const ChartIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
  </svg>
);

export const ArrowRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);

export const SparklesIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M9.315 7.584C11.12 6.135 12.88 6.135 14.685 7.584l.795.645a.75.75 0 001.252-.638V7.5c0-3.038-3.32-5.12-6.233-4.807A6.012 6.012 0 003.75 7.5v.091c0 .524.59.873 1.252.638l.795-.645zM6 11.25c0 .69.56 1.25 1.25 1.25H7.5a.75.75 0 000-1.5H7.25A.25.25 0 017 11.25H6zM8.25 10.5a.75.75 0 00-1.5 0v.75H6a.75.75 0 000 1.5h.75v.75a.75.75 0 001.5 0v-.75h.75a.75.75 0 000-1.5H8.25v-.75zM12 7.5a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0112 7.5zM16.75 11.25c0 .69-.56 1.25-1.25 1.25h-.25a.75.75 0 000 1.5h.25c1.518 0 2.75-1.232 2.75-2.75v-.75a.75.75 0 00-1.5 0V11.25z" clipRule="evenodd" />
    <path fillRule="evenodd" d="M6 15.75a.75.75 0 01.75-.75h.75a.75.75 0 010 1.5H6.75a.75.75 0 01-.75-.75zm.75 2.25a.75.75 0 00-1.5 0v.75a.75.75 0 001.5 0v-.75zM12.75 18a.75.75 0 00-1.5 0v.75a.75.75 0 001.5 0v-.75zM10.5 15.75a.75.75 0 01.75-.75h.75a.75.75 0 010 1.5h-.75a.75.75 0 01-.75-.75zm3.75 2.25a.75.75 0 00-1.5 0v.75a.75.75 0 001.5 0v-.75zM16.5 15.75a.75.75 0 01.75-.75h.75a.75.75 0 010 1.5H17.25a.75.75 0 01-.75-.75zm.75 2.25a.75.75 0 00-1.5 0v.75a.75.75 0 001.5 0v-.75z" clipRule="evenodd" />
  </svg>
);


export const LogoIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
    <path d="M2 17l10 5 10-5"></path>
    <path d="M2 12l10 5 10-5"></path>
  </svg>
);