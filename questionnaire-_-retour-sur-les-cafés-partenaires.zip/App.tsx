import React, { useState, useEffect, useCallback } from 'react';
import QuestionnaireForm from './components/QuestionnaireForm';
import ResultsDashboard from './components/ResultsDashboard';
import { FormIcon, ChartIcon, LogoIcon } from './components/icons';
import { Submission } from './types';
import { storageService } from './services/storageService';

type Tab = 'questionnaire' | 'results';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('questionnaire');
  const [submissions, setSubmissions] = useState<Submission[]>([]);

  useEffect(() => {
    const loadedSubmissions = storageService.getSubmissions();
    setSubmissions(loadedSubmissions);
  }, []);

  const handleAddSubmission = useCallback((newSubmission: Submission) => {
    storageService.addSubmission(newSubmission);
    setSubmissions(prev => [...prev, newSubmission]);
    setActiveTab('results');
    window.scrollTo(0, 0);
  }, []);

  const TabButton = ({ tab, label, icon }: { tab: Tab; label: string; icon: React.ReactNode }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`flex items-center justify-center w-full px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary ${
        activeTab === tab
          ? 'bg-brand-secondary text-white shadow-md'
          : 'bg-white text-brand-text hover:bg-gray-100'
      }`}
    >
      {icon}
      <span className="ml-2">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-brand-background text-brand-text">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center">
              <LogoIcon className="h-10 w-10 text-brand-primary" />
              <h1 className="ml-3 text-xl sm:text-2xl font-bold text-brand-text">
                CAP Formations
              </h1>
            </div>
            <div className="hidden sm:block">
              <span className="text-sm text-brand-text-light">Renforcer le réseau et l'accompagnement des jeunes</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="sticky top-4 z-10 bg-brand-background/80 backdrop-blur-sm rounded-xl shadow-lg p-2 mb-8">
          <div className="grid grid-cols-2 gap-2">
            <TabButton tab="questionnaire" label="Questionnaire" icon={<FormIcon />} />
            <TabButton tab="results" label="Résultats" icon={<ChartIcon />} />
          </div>
        </div>

        <div className="transition-opacity duration-500 ease-in-out">
          {activeTab === 'questionnaire' && (
            <QuestionnaireForm onSubmit={handleAddSubmission} />
          )}
          {activeTab === 'results' && (
            <ResultsDashboard submissions={submissions} />
          )}
        </div>
      </main>

       <footer className="text-center py-6 mt-8 border-t border-gray-300">
          <p className="text-sm text-brand-text-light">&copy; {new Date().getFullYear()} CAP Formations. Tous droits réservés.</p>
      </footer>
    </div>
  );
};

export default App;