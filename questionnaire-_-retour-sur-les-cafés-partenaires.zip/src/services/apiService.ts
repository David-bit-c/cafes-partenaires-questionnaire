import { Submission } from '../types';

export interface ApiResponse {
  submissions: Submission[];
  summary: string;
  summaryError: string;
}

export const apiService = {
  getSubmissions: async (): Promise<ApiResponse> => {
    const response = await fetch('/api/submissions');
    if (!response.ok) {
      throw new Error('Failed to fetch submissions');
    }
    return response.json();
  },

  addSubmission: async (newSubmission: Omit<Submission, 'id' | 'submittedAt'>): Promise<Response> => {
    return fetch('/api/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newSubmission),
    });
  },
};
