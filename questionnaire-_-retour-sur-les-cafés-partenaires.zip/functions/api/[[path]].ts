
import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { GoogleGenAI } from "@google/genai";

// Add D1 types to fix TS errors in environments without @cloudflare/workers-types
interface D1PreparedStatement {
    bind(...values: any[]): D1PreparedStatement;
    run<T = unknown>(): Promise<{ success: boolean; meta: any }>;
    all<T = unknown>(): Promise<{ results: T[]; success: boolean; meta: any; }>;
}

interface D1Database {
    prepare(query: string): D1PreparedStatement;
}

// Définir les types ici pour être autonome, en miroir de src/types.ts
interface Submission {
    id: string;
    email: string;
    submittedAt: string;
    participatedInCafes: 'Oui' | 'Non';
    cafesKnowledge?: string; // JSON array
    cafesCommunication?: 'Oui' | 'Non';
    cafesCommunicationReason?: string;
    cafesEnjoyment?: string; // JSON array
    cafesEnjoymentOther?: string;
    observedChallenges: string; // JSON array
    observedChallengesOther?: string;
    challengesRanking: string; // JSON object
    specializationObstacles: string;
    professionalRole: string;
    professionalRoleOther?: string;
}

// Définition des types pour l'environnement Cloudflare (base de données, secrets)
type Bindings = {
  DB: D1Database;
  API_KEY: string;
};

const app = new Hono<{ Bindings: Bindings }>();

// Configurer CORS pour autoriser les requêtes depuis notre domaine frontend
app.use('/api/*', cors());

// Endpoint pour soumettre un nouveau formulaire
app.post('/api/submit', async (c) => {
  try {
    const body = await c.req.json();
    
    // Validation simple (une validation plus robuste avec Zod serait idéale en production)
    if (!body.email || !body.participatedInCafes) {
      return c.json({ error: 'Données manquantes' }, 400);
    }

    const submission: Submission = {
        id: crypto.randomUUID(),
        submittedAt: new Date().toISOString(),
        email: body.email,
        participatedInCafes: body.participatedInCafes,
        cafesKnowledge: JSON.stringify(body.cafesKnowledge || []),
        cafesCommunication: body.cafesCommunication,
        cafesCommunicationReason: body.cafesCommunicationReason,
        cafesEnjoyment: JSON.stringify(body.cafesEnjoyment || []),
        cafesEnjoymentOther: body.cafesEnjoymentOther,
        observedChallenges: JSON.stringify(body.observedChallenges || []),
        observedChallengesOther: body.observedChallengesOther,
        challengesRanking: JSON.stringify(body.challengesRanking || {}),
        specializationObstacles: body.specializationObstacles,
        professionalRole: body.professionalRole,
        professionalRoleOther: body.professionalRoleOther,
    };

    const { success } = await c.env.DB.prepare(
      `INSERT INTO submissions (id, submittedAt, email, participatedInCafes, cafesKnowledge, cafesCommunication, cafesCommunicationReason, cafesEnjoyment, cafesEnjoymentOther, observedChallenges, observedChallengesOther, challengesRanking, specializationObstacles, professionalRole, professionalRoleOther)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(...Object.values(submission)).run();

    if (success) {
      return c.json({ message: 'Soumission enregistrée' }, 201);
    } else {
      return c.json({ error: "Échec de l'enregistrement" }, 500);
    }
  } catch (e: any) {
    console.error("Erreur de soumission:", e);
    return c.json({ error: e.message }, 500);
  }
});


// Endpoint pour récupérer toutes les soumissions et générer la synthèse
app.get('/api/submissions', async (c) => {
    try {
        const { results } = await c.env.DB.prepare("SELECT * FROM submissions").all<Submission>();
        const submissions = results.map(s => ({
            ...s,
            cafesKnowledge: JSON.parse(s.cafesKnowledge || '[]'),
            cafesEnjoyment: JSON.parse(s.cafesEnjoyment || '[]'),
            observedChallenges: JSON.parse(s.observedChallenges || '[]'),
            challengesRanking: JSON.parse(s.challengesRanking || '{}')
        }));

        let summary = '';
        let summaryError = '';

        if (submissions.length >= 3) {
            try {
                const ai = new GoogleGenAI({ apiKey: c.env.API_KEY });
                const dataForAI = submissions.map(s => ({
                    role: s.professionalRole === 'Autre' ? s.professionalRoleOther : s.professionalRole,
                    challenges: s.observedChallenges,
                    ranking: s.challengesRanking,
                    obstacles: s.specializationObstacles
                }));

                const prompt = `Tu es un analyste expert pour une organisation sociale. Voici des données brutes de professionnels de terrain. Rédige une synthèse exécutive de 3-4 points clés en français, mettant en lumière les tendances les plus importantes. Sois concis et percutant. Données: ${JSON.stringify(dataForAI)}`;
                
                const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
                summary = response.text;

            } catch (aiError: any) {
                console.error("Erreur de l'API Gemini:", aiError);
                summaryError = "La synthèse IA n'a pas pu être générée.";
            }
        } else if (submissions.length > 0) {
            summaryError = "Pas assez de réponses (3 minimum) pour générer une synthèse.";
        }
        
        return c.json({ submissions, summary, summaryError });

    } catch (e: any) {
        console.error("Erreur de récupération:", e);
        return c.json({ error: e.message }, 500);
    }
});

export default {
  fetch: app.fetch,
};
